import java.util.List;
import java.util.Random;

public class RandomAI extends AIPlayer {
    private final Random random = new Random();

    public RandomAI(boolean isPlayerOne) {
        super(isPlayerOne);
    }

    @Override
    public Move makeMove(PlayableLogic gameStatus) {
        List<Position> validMoves = gameStatus.ValidMoves();
        if (validMoves.isEmpty()) {
            return null; // No valid moves
        }

        // Select a move based on a normal distribution
        int index = (int) Math.abs(random.nextGaussian() * validMoves.size() / 3);
        index = Math.min(index, validMoves.size() - 1); // Ensure index is within bounds
        Position chosenPosition = validMoves.get(index);

        // Randomly choose a disc type
        Disc disc = chooseDiscType(gameStatus);
        return new Move(chosenPosition, disc);
    }
    public void resetState() {
        this.reset_bombs_and_unflippedable(); // Reset bombs and unflippable discs for this AI player
    }


    private Disc chooseDiscType(PlayableLogic gameStatus) {
        Player currentPlayer = isPlayerOne ? gameStatus.getFirstPlayer() : gameStatus.getSecondPlayer();

        while (true) {
            int choice = random.nextInt(3); // Randomly choose between 0, 1, 2
            switch (choice) {
                case 0:
                    return new SimpleDisc(currentPlayer); // SimpleDisc
                case 1:
                    if (currentPlayer.getNumber_of_bombs() > 0) {
                        currentPlayer.reduce_bomb();
                        return new BombDisc(currentPlayer);
                    }
                    break;
                case 2:
                    if (currentPlayer.getNumber_of_unflippedable() > 0) {
                        currentPlayer.reduce_unflippedable();
                        return new UnflippableDisc(currentPlayer);
                    }
                    break;
            }
        }
    }
}
