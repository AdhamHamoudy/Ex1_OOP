import java.util.List;

public class GameState {
    private final Position placedPosition;
    private final Disc placedDisc;
    private final Disc[][] boardState;
    private final List<FlippedDisc> flippedDiscs; // Track flipped discs

    public GameState(Position placedPosition, Disc placedDisc, Disc[][] boardState, List<FlippedDisc> flippedDiscs) {
        this.placedPosition = placedPosition;
        this.placedDisc = placedDisc;
        this.boardState = boardState;
        this.flippedDiscs = flippedDiscs;
    }

    public Position getPlacedPosition() {
        return placedPosition;
    }

    public Disc getPlacedDisc() {
        return placedDisc;
    }

    public Disc[][] getBoardState() {
        return boardState;
    }

    public List<FlippedDisc> getFlippedDiscs() {
        return flippedDiscs;
    }
}
