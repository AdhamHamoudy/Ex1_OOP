import java.util.Comparator;
import java.util.List;

public class GreedyAI extends AIPlayer {

    public GreedyAI(boolean isPlayerOne) {
        super(isPlayerOne);
    }

    @Override
    public Move makeMove(PlayableLogic gameStatus) {
        List<Position> validMoves = gameStatus.ValidMoves();
        if (validMoves.isEmpty()) {
            return null; // No valid moves
        }

        Player currentPlayer = isPlayerOne ? gameStatus.getFirstPlayer() : gameStatus.getSecondPlayer();
        Disc simpleDisc = new SimpleDisc(currentPlayer);

        // Find the best move using a comparator
        Position bestMove = validMoves.stream()
                .max(Comparator.comparingInt((Position pos) -> gameStatus.countFlips(pos))
                        .thenComparingInt(Position::col)  // Prefer rightmost column
                        .thenComparingInt(Position::row)) // Prefer bottommost row
                .orElseThrow();

        return new Move(bestMove, simpleDisc);
    }
}
