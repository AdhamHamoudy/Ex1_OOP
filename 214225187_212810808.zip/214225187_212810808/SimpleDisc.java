public class SimpleDisc implements Disc {
    private Player SDOwner;

    public SimpleDisc(Player SDOwner) {
        this.SDOwner = SDOwner;
    }

    @Override
    public Player getOwner() {
        return SDOwner;
    }

    @Override
    public void setOwner(Player SDOwner) {
        this.SDOwner = SDOwner;
    }

    @Override
    public String getType() {
        return "⬤";
    }

    @Override
    public String toString() {
        // Use the Player object's default toString() method or other unique representation
        return "SimpleDisc owned by " + SDOwner;
    }
}
