import java.util.*;

public class GameLogic implements PlayableLogic {
    private static final int BOARD_SIZE = 8;
    private static final int MAX_BOMBS_PER_PLAYER = 3;
    private static final int MAX_UNFLIPPABLE_PER_PLAYER = 2;
    private Disc[][] board;
    private Player firstPlayer, secondPlayer;
    private boolean isFirstPlayerTurn = true;
    private Stack<GameState> moveStack = new Stack<>();
    private HashMap<Player, Integer> bombUsageMap;
    private HashMap<Player, Integer> unflippableUsageMap;

    public GameLogic() {
        board = new Disc[BOARD_SIZE][BOARD_SIZE];
        bombUsageMap = new HashMap<>();
        unflippableUsageMap = new HashMap<>(); // Initialize unflippable usage
    }

    @Override
    public void setPlayers(Player player1, Player player2) {
        if (player1 == null || player2 == null) {
            throw new IllegalArgumentException("Players cannot be null.");
        }
        this.firstPlayer = player1;
        this.secondPlayer = player2;
        bombUsageMap.put(player1, 0);
        bombUsageMap.put(player2, 0);
        unflippableUsageMap.put(player1, 0); // Initialize counters for UnflippableDisc
        unflippableUsageMap.put(player2, 0);
        initializeGameBoard();
    }


    private void initializeGameBoard() {
        board = new Disc[BOARD_SIZE][BOARD_SIZE];
        board[3][3] = new SimpleDisc(firstPlayer);
        board[4][4] = new SimpleDisc(firstPlayer);
        board[3][4] = new SimpleDisc(secondPlayer);
        board[4][3] = new SimpleDisc(secondPlayer);
    }

    @Override
    public boolean locate_disc(Position position, Disc disc) {
        if (!isValidMove(position, disc)) {
            return false;
        }

        Player currentPlayer = disc.getOwner();

        // Enforce BombDisc limit
        if (disc instanceof BombDisc) {
            int usedBombs = bombUsageMap.get(currentPlayer);
            if (usedBombs >= MAX_BOMBS_PER_PLAYER) {
                System.out.printf("Player %d cannot place more BombDiscs (limit reached).%n",
                        getPlayerNumber(currentPlayer));
                return false;
            }
            bombUsageMap.put(currentPlayer, usedBombs + 1);
        }

        // Enforce UnflippableDisc limit
        if (disc instanceof UnflippableDisc) {
            int usedUnflippables = unflippableUsageMap.get(currentPlayer);
            if (usedUnflippables >= MAX_UNFLIPPABLE_PER_PLAYER) {
                System.out.printf("Player %d cannot place more UnflippableDiscs (limit reached).%n",
                        getPlayerNumber(currentPlayer));
                return false;
            }
            unflippableUsageMap.put(currentPlayer, usedUnflippables + 1);
        }

        // Save the board state and process the move
        System.out.printf("Player %d placed a %s in (%d, %d)%n",
                getPlayerNumber(currentPlayer), disc.getType(), position.row(), position.col());
        Disc[][] boardSnapshot = deepCopyBoard(board);
        List<FlippedDisc> flippedDiscs;

        if (disc instanceof BombDisc) {
            flippedDiscs = triggerBomb(position.row(), position.col(), disc);
        } else {
            flippedDiscs = flipDiscs(position, disc);
        }

        moveStack.push(new GameState(position, disc, boardSnapshot, flippedDiscs));
        board[position.row()][position.col()] = disc;
        isFirstPlayerTurn = !isFirstPlayerTurn;
        System.out.println(); // Blank line after the move
        return true;
    }


    private int getPlayerNumber(Player player) {
        if (player == firstPlayer) {return 1;} else if (player == secondPlayer) {return 2;}
        else {throw new IllegalArgumentException("Unknown player.");}
    }

    private Disc[][] deepCopyBoard(Disc[][] originalBoard) {
        Disc[][] copy = new Disc[BOARD_SIZE][BOARD_SIZE];
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                if (originalBoard[i][j] instanceof BombDisc) {
                    copy[i][j] = new BombDisc(originalBoard[i][j].getOwner());
                } else if (originalBoard[i][j] instanceof SimpleDisc) {
                    copy[i][j] = new SimpleDisc(originalBoard[i][j].getOwner());
                } else if (originalBoard[i][j] instanceof UnflippableDisc) {
                    copy[i][j] = new UnflippableDisc(originalBoard[i][j].getOwner());
                } else {
                    copy[i][j] = null; // Empty cells remain null
                }
            }
        }
        return copy;
    }

    private List<Position> getDirections() {
        List<Position> directions = new ArrayList<>();
        for (int dRow = -1; dRow <= 1; dRow++) {
            for (int dCol = -1; dCol <= 1; dCol++) {
                if (dRow != 0 || dCol != 0) {
                    directions.add(new Position(dRow, dCol));
                }
            }
        }
        return directions;
    }
    private List<FlippedDisc> triggerBomb(int row, int col, Disc ownerDisc) {
        List<FlippedDisc> affectedDiscs = new ArrayList<>();
        boolean[][] triggered = new boolean[BOARD_SIZE][BOARD_SIZE];
        triggerBombRecursive(row, col, ownerDisc, triggered, affectedDiscs);
        return affectedDiscs;
    }
    private void triggerBombRecursive(int row, int col, Disc ownerDisc, boolean[][] triggered, List<FlippedDisc> affectedDiscs) {
        triggered[row][col] = true;

        for (Position direction : getDirections()) {
            int neighborRow = row + direction.row();
            int neighborCol = col + direction.col();

            if (isInBounds(neighborRow, neighborCol) && !triggered[neighborRow][neighborCol]) {
                Disc neighborDisc = board[neighborRow][neighborCol];
                if (neighborDisc != null) {
                    // Process discs affected by the bomb
                    if (neighborDisc.getOwner() != ownerDisc.getOwner() && !(neighborDisc instanceof UnflippableDisc)) {
                        affectedDiscs.add(new FlippedDisc(new Position(neighborRow, neighborCol), neighborDisc));

                        // Print the flipped disc information
                        System.out.printf("Player %d flipped the %s in (%d, %d)%n",
                                getPlayerNumber(ownerDisc.getOwner()), neighborDisc.getType(), neighborRow, neighborCol);

                        if (neighborDisc instanceof BombDisc) {
                            // Trigger chain reaction
                            board[neighborRow][neighborCol] = new BombDisc(ownerDisc.getOwner());
                            triggerBombRecursive(neighborRow, neighborCol, ownerDisc, triggered, affectedDiscs);
                        } else {
                            // Flip the disc
                            board[neighborRow][neighborCol] = new SimpleDisc(ownerDisc.getOwner());
                        }
                    }
                }
            }
        }
    }

    private List<Position> getFlippedPositionsInDirection(Position start, Position direction, Disc placedDisc) {
        List<Position> flippedPositions = new ArrayList<>();
        int row = start.row() + direction.row();
        int col = start.col() + direction.col();

        while (isInBounds(row, col)) {
            Disc currentDisc = board[row][col];

            // Stop if we encounter an empty space
            if (currentDisc == null) {
                return new ArrayList<>(); // No valid flips possible
            }

            // If we encounter a friendly disc, validate flips
            if (currentDisc.getOwner() == placedDisc.getOwner()) {
                return flippedPositions.isEmpty() ? new ArrayList<>() : flippedPositions; // Return flips if valid
            }

            // Add enemy discs to the flip list (include UnflippableDisc as part of the line)
            if (!(currentDisc instanceof UnflippableDisc)) {
                flippedPositions.add(new Position(row, col));
            }

            // Move to the next position
            row += direction.row();
            col += direction.col();
        }

        // If no friendly disc is encountered, the flips are invalid
        return new ArrayList<>();
    }

    private boolean isValidMove(Position position, Disc disc) {
        // A move is invalid if the position is already occupied
        if (board[position.row()][position.col()] != null) {
            return false;
        }

        // Check all directions for at least one valid flip
        for (Position direction : getDirections()) {
            if (!getFlippedPositionsInDirection(position, direction, disc).isEmpty()) {
                return true; // At least one direction is valid
            }
        }

        return false; // No valid flips in any direction
    }
    private int countDiscs(Player player) {
        int count = 0;
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                Disc disc = board[row][col];
                // Include all disc types owned by the player, including BombDisc
                if (disc != null && disc.getOwner() == player) {
                    count++;
                }
            }
        }
        return count;
    }

    @Override
    public int countFlips(Position position) {
        int totalFlips = 0;
        Player currentPlayer = isFirstPlayerTurn ? firstPlayer : secondPlayer;
        Disc currentDisc = new SimpleDisc(currentPlayer);
        Set<Position> visited = new HashSet<>(); // Track already processed positions

        for (Position direction : getDirections()) {
            List<Position> flippedPositions = getFlippedPositionsInDirection(position, direction, currentDisc);

            for (Position flipPosition : flippedPositions) {
                Disc discAtPos = board[flipPosition.row()][flipPosition.col()];

                if (discAtPos != null && !(discAtPos instanceof UnflippableDisc)) {
                    // Count bombs and regular discs
                    if (discAtPos instanceof BombDisc && !visited.contains(flipPosition)) {
                        totalFlips += simulateBombFlips(flipPosition, currentPlayer, visited);
                    } else if (!visited.contains(flipPosition)) {
                        totalFlips++; // Count regular flippable discs
                        visited.add(flipPosition);
                    }
                }
            }
        }

        // Include the placed bomb disc itself if applicable
        Disc placedDisc = board[position.row()][position.col()];
        if (placedDisc instanceof BombDisc && placedDisc.getOwner() == currentPlayer) {
            totalFlips++;
        }

        return totalFlips;
    }


    private int simulateBombFlips(Position bombPosition, Player owner, Set<Position> visited) {
        int flips = 0;
        Queue<Position> queue = new LinkedList<>();
        queue.add(bombPosition);

        while (!queue.isEmpty()) {
            Position current = queue.poll();

            // Mark the bomb's position as visited to avoid reprocessing
            if (!visited.add(current)) {
                continue;
            }

            // Count the bomb itself if owned by the current player
            Disc bombDisc = board[current.row()][current.col()];
            if (bombDisc != null && bombDisc.getOwner() == owner) {
                flips++; // Count the bomb as a disc
            }

            // Check all adjacent positions (8 directions)
            for (Position direction : getDirections()) {
                int neighborRow = current.row() + direction.row();
                int neighborCol = current.col() + direction.col();
                Position neighborPosition = new Position(neighborRow, neighborCol);

                if (isInBounds(neighborRow, neighborCol) && !visited.contains(neighborPosition)) {
                    Disc neighborDisc = board[neighborRow][neighborCol];

                    if (neighborDisc != null) {
                        // Count flippable discs, excluding UnflippableDisc
                        if (!(neighborDisc instanceof UnflippableDisc)) {
                            flips++;
                        }

                        // If the neighbor is a BombDisc, queue it for further processing
                        if (neighborDisc instanceof BombDisc) {
                            queue.add(neighborPosition);
                        }
                    }
                }
            }
        }

        return flips;
    }

    private List<FlippedDisc> flipDiscs(Position position, Disc disc) {
        List<FlippedDisc> flippedDiscs = new ArrayList<>();
        // Use a Set to track processed positions to avoid duplicate prints
        HashSet<Position> processedPositions = new HashSet<>();

        for (Position direction : getDirections()) {
            List<Position> flippedPositions = getFlippedPositionsInDirection(position, direction, disc);
            for (Position flipPosition : flippedPositions) {
                Disc originalDisc = board[flipPosition.row()][flipPosition.col()];

                // Skip flipping for UnflippableDisc
                if (originalDisc instanceof UnflippableDisc) {
                    continue;
                }

                // Record flip for undo
                flippedDiscs.add(new FlippedDisc(flipPosition, originalDisc));

                // Perform the flip
                if (originalDisc instanceof BombDisc) {
                    board[flipPosition.row()][flipPosition.col()] = new BombDisc(disc.getOwner());
                    triggerBombWithTracking(flipPosition.row(), flipPosition.col(), disc.getOwner(), processedPositions, flippedDiscs);
                } else {
                    board[flipPosition.row()][flipPosition.col()] = new SimpleDisc(disc.getOwner());
                }

                // Print flip only if not already processed
                if (!processedPositions.contains(flipPosition)) {
                    System.out.printf("Player %d flipped the %s in (%d, %d)%n",
                            getPlayerNumber(disc.getOwner()), originalDisc.getType(), flipPosition.row(), flipPosition.col());
                    processedPositions.add(flipPosition); // Mark position as processed
                }
            }
        }
        return flippedDiscs;
    }

    private void triggerBombWithTracking(int row, int col, Player owner, HashSet<Position> processedPositions, List<FlippedDisc> flippedDiscs) {
        boolean[][] triggered = new boolean[BOARD_SIZE][BOARD_SIZE];
        triggerBombRecursiveWithTracking(row, col, owner, triggered, processedPositions, flippedDiscs);
    }

    private void triggerBombRecursiveWithTracking(int row, int col, Player owner, boolean[][] triggered, HashSet<Position> processedPositions, List<FlippedDisc> flippedDiscs) {
        triggered[row][col] = true;

        for (Position direction : getDirections()) {
            int neighborRow = row + direction.row();
            int neighborCol = col + direction.col();

            if (isInBounds(neighborRow, neighborCol) && !triggered[neighborRow][neighborCol]) {
                Disc neighborDisc = board[neighborRow][neighborCol];
                if (neighborDisc != null) {
                    // Add only discs that are not owned by the bomb's owner and not unflippable
                    if (neighborDisc.getOwner() != owner && !(neighborDisc instanceof UnflippableDisc)) {
                        flippedDiscs.add(new FlippedDisc(new Position(neighborRow, neighborCol), neighborDisc));

                        if (neighborDisc instanceof BombDisc) {
                            // Trigger chain reaction
                            board[neighborRow][neighborCol] = new BombDisc(owner); // Fixed the typo
                            triggerBombRecursiveWithTracking(neighborRow, neighborCol, owner, triggered, processedPositions, flippedDiscs);
                        } else {
                            // Flip enemy discs
                            board[neighborRow][neighborCol] = new SimpleDisc(owner);
                        }

                        // Print flip only if not already processed
                        Position currentPosition = new Position(neighborRow, neighborCol);
                        if (!processedPositions.contains(currentPosition)) {
                            System.out.printf("Player %d flipped the %s in (%d, %d)%n",
                                    getPlayerNumber(owner), neighborDisc.getType(), neighborRow, neighborCol);
                            processedPositions.add(currentPosition);
                        }
                    }
                }
            }
        }
    }

    private boolean isInBounds(int row, int col) {
        return row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE;
    }

    @Override
    public boolean isGameFinished() {
        // Check if both players have no valid moves
        if (ValidMoves().isEmpty()) {
            declareWinner();
            return true;
        }
        return false;
    }

    private void declareWinner() {
        int firstPlayerCount = countDiscs(firstPlayer);
        int secondPlayerCount = countDiscs(secondPlayer);

        if (firstPlayerCount > secondPlayerCount) {
            firstPlayer.addWin();
            System.out.printf("Player 1 wins with %d discs! Player 2 had %d discs.%n", firstPlayerCount, secondPlayerCount);

        } else if (secondPlayerCount > firstPlayerCount) {
            secondPlayer.addWin();
            System.out.printf("Player 2 wins with %d discs! Player 1 had %d discs.%n", secondPlayerCount, firstPlayerCount);
        }
    }

    @Override
    public void undoLastMove() {
        // Check if undo is allowed only for human players
        if (!firstPlayer.isHuman() || !secondPlayer.isHuman()) {
            System.out.println("Undo is not allowed when there is an AI player.");
            return;
        }
        if (moveStack.isEmpty()) {
            System.out.println("\tNo previous move available to undo.");
            return;
        }

        System.out.println("Undoing last move:");

        // Pop the last move
        GameState lastMove = moveStack.pop();

        // Restore the board state from the snapshot
        Disc[][] previousBoardState = lastMove.getBoardState();
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                board[row][col] = previousBoardState[row][col];
            }
        }

        // Retrieve the position and placed disc for logs
        Position lastPosition = lastMove.getPlacedPosition();
        Disc placedDisc = lastMove.getPlacedDisc();
        Player originalOwner = placedDisc.getOwner();

        // Log the removal of the last disc
        System.out.printf("\tUndo: removing %s from (%d, %d)%n",
                placedDisc.getType(), lastPosition.row(), lastPosition.col());

        // Restore flipped discs
        List<FlippedDisc> flippedDiscs = lastMove.getFlippedDiscs();
        Set<Position> processedPositions = new HashSet<>(); // Track already printed positions

        for (FlippedDisc flippedDisc : flippedDiscs) {
            Position position = flippedDisc.getPosition();

            // Only print if the position hasn't been processed yet
            if (!processedPositions.contains(position)) {
                Disc disc = flippedDisc.getOriginalDisc();
                System.out.printf("\tUndo: flipping back %s in (%d, %d)%n",
                        disc.getType(), position.row(), position.col());
                processedPositions.add(position); // Mark this position as processed
            }
        }

        // Restore the special disc usage counters
        if (placedDisc instanceof BombDisc) {
            bombUsageMap.put(originalOwner, bombUsageMap.get(originalOwner) - 1);
        } else if (placedDisc instanceof UnflippableDisc) {
            unflippableUsageMap.put(originalOwner, unflippableUsageMap.get(originalOwner) - 1);
        }

        // Switch turn back
        isFirstPlayerTurn = !isFirstPlayerTurn;

        // Print a blank line after undoing
        System.out.println();
    }

    @Override
    public List<Position> ValidMoves() {
        List<Position> validMoves = new ArrayList<>();
        Player currentPlayer = isFirstPlayerTurn ? firstPlayer : secondPlayer;
        Disc currentDisc = new SimpleDisc(currentPlayer);

        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                Position position = new Position(row, col);
                if (isValidMove(position, currentDisc)) {
                    validMoves.add(position);
                }
            }
        }
        return validMoves;
    }

    @Override
    public Disc getDiscAtPosition(Position position) {
        return board[position.row()][position.col()];
    }

    @Override
    public boolean isFirstPlayerTurn() {
        return isFirstPlayerTurn;
    }

    @Override
    public Player getFirstPlayer() {
        return firstPlayer;
    }

    @Override
    public Player getSecondPlayer() {
        return secondPlayer;
    }

    @Override
    public int getBoardSize() {
        return BOARD_SIZE;
    }

    @Override
    public void reset() {
        initializeGameBoard();
        moveStack.clear();

        bombUsageMap.put(firstPlayer, 0);
        bombUsageMap.put(secondPlayer, 0);
        unflippableUsageMap.put(firstPlayer, 0);
        unflippableUsageMap.put(secondPlayer, 0);

        // Reset bomb and unflippable counters for both players
        firstPlayer.reset_bombs_and_unflippedable();
        secondPlayer.reset_bombs_and_unflippedable();

        // If the player is AI, reset its state
        if (firstPlayer instanceof RandomAI) {
            ((RandomAI) firstPlayer).resetState();
        }
        if (secondPlayer instanceof RandomAI) {
            ((RandomAI) secondPlayer).resetState();
        }

        isFirstPlayerTurn = true;
    }
}
