public class BombDisc implements Disc {
    private Player BDOwner;
    public BombDisc(Player BDOwner) {
        this.BDOwner = BDOwner;
    }

    @Override
    public Player getOwner() {
        return BDOwner;
    }

    @Override
    public void setOwner(Player player) {
        BDOwner = player;
    }

    @Override
    public String getType() {
        return "\uD83D\uDCA3";
    }
}
