public class UnflippableDisc implements Disc {
    private Player UFDOwner;

    public UnflippableDisc(Player UFDOwner) {
        this.UFDOwner = UFDOwner;
    }

    @Override
    public Player getOwner() {
        return UFDOwner;
    }

    @Override
    public void setOwner(Player player) {
        UFDOwner = player;
    }

    @Override
    public String getType() {
        return "⭕";
    }

    @Override
    public String toString() {
        return "UnflippableDisc owned by " + UFDOwner;
    }
}
