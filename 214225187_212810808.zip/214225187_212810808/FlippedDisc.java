class FlippedDisc {
    private final Position position;
    private final Disc originalDisc;

    public FlippedDisc(Position position, Disc originalDisc) {
        this.position = position;
        this.originalDisc = originalDisc;
    }

    public Position getPosition() {
        return position;
    }

    public Disc getOriginalDisc() {
        return originalDisc;
    }
}
